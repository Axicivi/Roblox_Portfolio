
=== Roblox Video Portfolio ===

1. Để thay video:
- Đổi tên video của bạn thành 'video.mp4'
- Kéo nó vào repo GitHub, ghi đè file cũ

2. Cách up lên GitHub Pages:
- Tạo repository mới → Kéo các file trong folder này vào
- Vào Settings → Pages → Chọn "Deploy from a branch" (main / root)
- Link sẽ hiện ra sau vài phút: https://<username>.github.io/<repo-name>/

Enjoy!
